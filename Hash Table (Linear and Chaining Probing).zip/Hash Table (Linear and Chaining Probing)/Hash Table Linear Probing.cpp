#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 10
#define LENGTH 100

struct Stuff{
	char name[LENGTH];
	int price;
} *bucket[SIZE];

int count = 0;

struct Stuff* new_node(char name[LENGTH], int price){
	struct Stuff* node = (struct Stuff*)malloc(sizeof(struct Stuff));
	strcpy(node->name, name);
	node->price = price;
	
	return node;
}

int hash(char name[LENGTH]){
	int i = 0;
	int key = 0;
	int len = strlen(name);
	for(i = 0; i<len; i++){
		key += name[i];
	}
	
	return key %SIZE;
}

void insert(char name[LENGTH], int price){
	int hashkey = hash(name);
	int pos = hashkey;
	
	//Semua laci Penuh
	if(count == SIZE){
		printf("Bucket Overloaded\n");
		return;
	}
	//Collision
	while(bucket[pos] != NULL){
		pos = (pos + 1) %SIZE;
	}
	//Laci Kosong
	bucket[pos] = new_node(name, price);
	count++;
}

void view(){
	int i=0;
	
	for(i = 0; i < SIZE; i++){
		if(bucket[i]){
			printf("%s: %d. hashkey: %d\n", bucket[i]->name, bucket[i]->price, 
			hash(bucket[i]->name));
		}
		else{
			printf("-\n");
		}
	}
}

struct Stuff* search(char name[LENGTH]){
	int hashkey = hash(name);
	int pos = hashkey;
	
	do{
		if(bucket[pos] && strcmp(bucket[pos]->name, name) == 0){
			return bucket[pos];
		}
		pos = (pos+1) % SIZE;
	}while(pos != hashkey);
	
	return NULL;
}

void removes(char name[LENGTH]){
	int hashkey = hash(name);
	int pos = hashkey;
	
	do{
		if(bucket[pos] && strcmp(bucket[pos]->name, name) == 0){
			free(bucket[pos]);
			bucket[pos] = NULL;
			return;
		}
		pos = (pos+1) % SIZE;
	}while(pos != hashkey);
	
	return;
}

int main(){
	
	insert("biola", 20);
	insert("ayam", 10);
	insert("ikan", 25);
	
	insert("maya", 25);
//	removes("biola");
	view();
	
	if(search("ikan")){
		printf("Found\n");
	}
	else{
		printf("Not Found\n");
	}
	return 0;
}

