#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#define HASH_SIZE 6

struct Node{
	int value;
	char key[100];
	struct Node *next;
};

int get_hash_key(char key[]){
	int value = 0;
	int i, len = strlen(key);
	
	for(i = 0; i<len;i++){
		value += tolower(key[i]) - 'a';
	}
	return value % HASH_SIZE;
}

struct Node* new_node(char key[], int value){
	struct Node *temp = (struct Node*) malloc(sizeof(struct Node));
	strcpy(temp->key, key);
	temp->value = value;
	temp->next = NULL;
	
	return temp;
}

struct Node *insert_node (Node *curr, char key[], int value){
	if(curr == NULL){
		return new_node(key, value);
	}
	else if(strcmp(curr->key, key) == 0){
		curr->value = value;
		return curr;
	}
	curr->next = insert_node(curr->next, key, value); 
	
	return curr;
}

void insert(struct Node *head[], char key[], int value){
	int hash_key = get_hash_key(key);
	head [hash_key] = insert_node(head[hash_key], key, value);
}

struct Node *search_node(struct Node *curr, char key[]){
	if(curr == NULL){
		return NULL;
	}
	else if(strcmp(curr->key, key) == 0){
		return curr;
	}
	
	return search_node(curr->next, key);
}

void search(struct Node *head[], char key[]){
	struct Node *temp;
	int hash_key = get_hash_key(key);
	
	temp = search_node(head[hash_key], key);
	
	if(temp == NULL){
		printf("\nKey %s tidak ditemukan\n", key);
	}
	else{
		printf("\nData ditemukan! Key %s Value %d\n", key, temp->value);
	}
}

struct Node *delete_node(struct Node *curr, char key[]){
	if(curr == NULL){
		return NULL;
	}
	else if(strcmp(curr->key, key) == 0){
		struct Node *temp = curr->next;
		
		free(curr);
		
		return temp;
	}
	curr->next = delete_node(curr->next, key);
	return curr;
}

void deletes(struct Node *head[], char key[]){
	struct Node *temp;
	int hash_key = get_hash_key(key);
	
	temp = search_node(head[hash_key], key);
	
	if(temp == NULL){
		printf("\nKey %s tidak ditemukan\n", key);
	}
	else{
		printf("\nData Dihapus! Key %s Value %d\n", key, temp->value);
		head[hash_key] = delete_node(head[hash_key], key);
	}
}


void print(struct Node *head[]){
	int i;
	for(i = 0; i < HASH_SIZE; i++){
		printf("%d: ", i);
		struct Node *curr = head[i];
		
		while(curr != NULL){
			printf("%s, %d ", curr->key, curr->value);
			if(curr->next != NULL){
				printf("->  ");
			}
			curr  = curr->next;
		}
		printf("\n");
	}
}

int main (){
	struct Node *head[HASH_SIZE] = {NULL};
	
//	printf("%d\n", get_hash_key("air"));
	
	insert(head, "Food", 442);
	insert(head, "Maya", 123);
	insert(head, "food", 12);
	
//	print(head);
//	
//	insert(head, "Food", 511);
	
	print(head);
	search(head, "Food");
	search(head, "mengkudu");
	
	deletes(head, "Maya");
	deletes(head, "Mengkudu");
	
	print(head);
	
	return 0;
}
